package gr8pefish.ironbackpacks.proxy;

public class ServerProxy extends CommonProxy {
}
