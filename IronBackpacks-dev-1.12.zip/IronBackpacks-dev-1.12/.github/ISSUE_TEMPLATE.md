Note: Delete the following 2 lines when you submit the issue. 
* If this bug occurs in a modpack, please try first reporting it to the modpack author. Barring that, please narrow down exactly what other mod(s) are responsible for the issue. 
* If this is a feature request, this template does not apply to you. Just delete everything and write what you need.

#### Issue Description:



#### What happens:



#### What you expected to happen:



#### Steps to reproduce (important):

1. 
2. 
3. 
...

____
#### Affected Versions (Do *not* use "latest"):

- IronBackpacks: 
- Minecraft: 
- Forge: 
- Other Conflicting Mods (may be irrelevant to your issue):